import { showTransportLayer, hideTransportLayer } from "../views/transport.view.js";

let visible = false;

export function initUI() {
  const btn = document.getElementById("toggle-transports");

  btn.addEventListener("click", () => {
    visible = !visible;

    if (visible) {
      showTransportLayer();
      btn.textContent = "❌ Masquer les transports";
    } else {
      hideTransportLayer();
      btn.textContent = "🚆 Afficher les transports";
    }
  });
}
