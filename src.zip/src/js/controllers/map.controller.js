import { state } from "../app/state.js";
import * as Geo from "../models/geo.model.js";
import * as MapView from "../views/map.view.js";
import * as Panel from "../views/panel.view.js";
import { transportsInBounds, extractAccessibility } from "../utils/utils.js";

/**
 * Démarrage
 */
export async function startApp() {
  const geo = await Geo.loadDepartmentsGeo();

  state.layers.dept = MapView.renderDepartments(
    state.map,
    geo,
    state.data.statsDept,
    onDepartmentClick
  );
}

/**
 * Département
 */
async function onDepartmentClick(feature, layer) {
  const bounds = layer.getBounds();
  state.map.fitBounds(bounds, { padding: [40, 40] });

  state.layers.commune = MapView.clearLayer(state.map, state.layers.commune);
  state.layers.section = MapView.clearLayer(state.map, state.layers.section);

  const transports = transportsInBounds(state.data.transports, bounds);

  console.log("Transports visibles :", transports.length);
console.log(transports[0]);

  Panel.showDeptPanel(
    feature.properties.nom,
    state.data.statsDept[feature.properties.code_insee],
    transports
  );

  const geoCommunes = await Geo.loadCommunesGeo(feature.properties.code_insee);
  state.layers.commune = MapView.renderCommunes(
    state.map,
    geoCommunes,
    state.data.prixCommune,
    (f, l) => onCommuneClick(feature.properties.code_insee, f, l)
  );
}

/**
 * Commune
 */
async function onCommuneClick(codeDept, feature, layer) {
  const bounds = layer.getBounds();
  state.map.fitBounds(bounds, { padding: [30, 30] });

  state.layers.section = MapView.clearLayer(state.map, state.layers.section);

  const ventes = state.data.ventesByCommune.get(feature.properties.id) ?? [];
  const transports = transportsInBounds(state.data.transports, bounds);

  console.log("Transports visibles :", transports.length);
console.log(transports[0]);

  Panel.showCommunePanel(feature.properties.nom, ventes, transports);

  const geoSections = await Geo.loadSectionsGeo(codeDept);
  const sections = geoSections.features.filter(
    f => f.properties.commune === feature.properties.id
  );

  state.layers.section = MapView.renderSections(
    state.map,
    sections,
    state.data.prixSection,
    (f, l) => onSectionClick(feature.properties.nom, f, l)
  );
}

/**
 * Section
 */
function onSectionClick(nomCommune, feature, layer) {
  const bounds = layer.getBounds();

  const ventes = state.data.ventesBySection.get(feature.properties.id) ?? [];
  const transports = transportsInBounds(state.data.transports, bounds);
 console.log("Transports visibles :", transports.length);
console.log(transports[0]);


  Panel.showSectionPanel(
    nomCommune,
    feature.properties.code,
    ventes,
    transports
  );
}
