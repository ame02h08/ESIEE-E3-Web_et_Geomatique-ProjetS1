import { state } from "./app/state.js";
import { initMap } from "./views/map.view.js";
import { initLegend } from "./views/legend.view.js";
import { loadDVF, computeStatsByDept, aggregateMedianByKey, buildIndexes } from "./models/dvf.model.js";
import { loadTransports } from "./models/transport.model.js";
import { startApp } from "./controllers/map.controller.js";
import { initUI } from "./controllers/ui.controller.js";

(async () => {
  // 1) Map
  state.map = initMap();
  initLegend(state.map);

  // 2) DVF
  state.data.dvf = await loadDVF();

  state.data.statsDept = computeStatsByDept(state.data.dvf);
  state.data.prixCommune = aggregateMedianByKey(state.data.dvf, "commune");
  state.data.prixSection = aggregateMedianByKey(state.data.dvf, "section");

  const { ventesByCommune, ventesBySection } = buildIndexes(state.data.dvf);
  state.data.ventesByCommune = ventesByCommune;
  state.data.ventesBySection = ventesBySection;

  // 3) 🚆 TRANSPORTS (AVANT startApp)
  state.data.transports = await loadTransports();
  console.log("🚆 transports chargés :", state.data.transports?.features?.length);

  // 4) Carte métier
  await startApp();

  // 5) UI (boutons, etc.)
  initUI();
})();
