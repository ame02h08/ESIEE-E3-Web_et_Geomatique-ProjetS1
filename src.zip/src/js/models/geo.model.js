export async function loadDepartmentsGeo() {
  return fetch("data/idf.geojson").then(r => r.json());
}

export async function loadCommunesGeo(codeDept) {
  return fetch(`data/${codeDept}/communes-${codeDept}.geojson`).then(r => r.json());
}

export async function loadSectionsGeo(codeDept) {
  return fetch(`data/${codeDept}/sections-${codeDept}.geojson`).then(r => r.json());
}
