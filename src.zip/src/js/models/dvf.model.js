import { median } from "../utils/utils.js";

export async function loadDVF() {
  const rows = await d3.csv("data/dvf_filtre.csv", d => {
    const surface = +d.surface_reelle_bati;
    const valeur = +d.valeur_fonciere;
    if (!surface || !valeur) return null;

    return {
      dept: d.code_commune.slice(0, 2),
      commune: d.code_commune,
      section: d.id_parcelle ? d.id_parcelle.slice(0, -4) : null,
      type: d.type_local,
      prix: valeur / surface,
      valeur_fonciere: valeur,
      surface,
      nb_pieces: +d.nombre_pieces_principales || null,
      date: d.date_mutation,
      adresse: `${d.adresse_numero || ""} ${d.adresse_nom_voie || ""}`.trim(),
      code_postal: d.code_postal
    };
  });

  return rows.filter(Boolean);
}

export function computeStats(ventes) {
  if (!ventes || ventes.length === 0) {
    return { ventes: 0, prixMedian: null, maisons: 0, apparts: 0, prixMaisons: null, prixApparts: null };
  }

  const prix = ventes.map(v => v.prix);
  const maisons = ventes.filter(v => v.type === "Maison");
  const apparts = ventes.filter(v => v.type === "Appartement");

  return {
    ventes: ventes.length,
    prixMedian: median(prix),
    maisons: maisons.length,
    apparts: apparts.length,
    prixMaisons: maisons.length ? median(maisons.map(v => v.prix)) : null,
    prixApparts: apparts.length ? median(apparts.map(v => v.prix)) : null
  };
}

export function computeStatsByDept(data) {
  const g = {};
  data.forEach(d => {
    if (!g[d.dept]) g[d.dept] = { ventes: 0, prix: [], maisons: 0, apparts: 0 };
    g[d.dept].ventes++;
    g[d.dept].prix.push(d.prix);
    if (d.type === "Maison") g[d.dept].maisons++;
    if (d.type === "Appartement") g[d.dept].apparts++;
  });

  const res = {};
  for (const k in g) {
    res[k] = {
      ventes: g[k].ventes,
      prixMedian: median(g[k].prix),
      maisons: g[k].maisons,
      apparts: g[k].apparts
    };
  }
  return res;
}

export function aggregateMedianByKey(data, key) {
  const g = {};
  data.forEach(d => {
    if (!d[key]) return;
    if (!g[d[key]]) g[d[key]] = [];
    g[d[key]].push(d.prix);
  });
  const res = {};
  for (const k in g) res[k] = median(g[k]);
  return res;
}

export function buildIndexes(data) {
  const ventesByCommune = new Map();
  const ventesBySection = new Map();

  for (const v of data) {
    if (v.commune) {
      if (!ventesByCommune.has(v.commune)) ventesByCommune.set(v.commune, []);
      ventesByCommune.get(v.commune).push(v);
    }
    if (v.section) {
      if (!ventesBySection.has(v.section)) ventesBySection.set(v.section, []);
      ventesBySection.get(v.section).push(v);
    }
  }

  return { ventesByCommune, ventesBySection };
}
