export async function loadTransports() {
  const rows = await d3.dsv(";", "data/transports_idf.csv");

  const features = [];

  for (const d of rows) {
    if (!d["Geo Shape"]) continue;

    let geometry;
    try {
      geometry = JSON.parse(d["Geo Shape"].replace(/""/g, '"'));
    } catch {
      continue;
    }

    // déterminer le mode
    let mode = "AUTRE";
    if (d.metro === "1") mode = "METRO";
    else if (d.rer === "1") mode = "RER";
    else if (d.tramway === "1") mode = "TRAMWAY";
    else if (d.train === "1") mode = "TRAIN";

    features.push({
      type: "Feature",
      geometry,
      properties: {
        mode,
        ligne: d.SHAPE_Lig || d.indice_lig || d.res_com,
        couleur: d.ColourWeb_hexa ? `#${d.ColourWeb_hexa}` : "#999999"
      }
    });
  }

  return {
    type: "FeatureCollection",
    features
  };
}
