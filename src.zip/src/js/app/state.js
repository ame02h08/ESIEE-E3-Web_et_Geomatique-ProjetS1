export const state = {
  map: null,

  layers: {
    dept: null,
    commune: null,
    section: null,
    transport: null
  },

  data: {
    dvf: [],
    transports: [],
    statsDept: {},
    prixCommune: {},
    prixSection: {},
    ventesByCommune: new Map(),
    ventesBySection: new Map()
  }
};
