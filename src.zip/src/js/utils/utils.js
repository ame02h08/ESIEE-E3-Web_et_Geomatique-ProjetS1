// ==========================
// Médiane
// ==========================
export function median(values) {
  if (!values || values.length === 0) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2
    ? sorted[mid]
    : (sorted[mid - 1] + sorted[mid]) / 2;
}

// ==========================
// Arrondis
// ==========================
export function roundDown100(n) {
  if (n == null || isNaN(n)) return null;
  return Math.floor(n / 100) * 100;
}

export function roundUp100(n) {
  if (n == null || isNaN(n)) return null;
  return Math.ceil(n / 100) * 100;
}

// ===================================================
// Calcul des seuils de quantiles
// ===================================================
export function computeQuantiles(values, n = 9) {
  if (!values || values.length === 0) return [];
  const sorted = [...values].sort((a, b) => a - b);
  const q = [];
  for (let i = 1; i < n; i++) {
    const pos = Math.floor((i / n) * sorted.length);
    q.push(sorted[pos]);
  }
  return q;
}

// ===================================================
// Palette
// ===================================================
export function heatPalette() {
  return [
    "#006400",
    "#1e8f3a",
    "#6cc04a",
    "#b6e43a",
    "#ffd700",
    "#ffb000",
    "#ff8c00",
    "#ff3b1f",
    "#8b0000"
  ];
}

// ===================================================
// Couleur par quantile
// ===================================================
export function heatColorQuantile(value, quantiles) {
  if (value == null || isNaN(value)) return "#cccccc";
  const palette = heatPalette();
  for (let i = 0; i < quantiles.length; i++) {
    if (value <= quantiles[i]) return palette[i];
  }
  return palette[palette.length - 1];
}

// ==========================
// Format €
// ==========================
export function fmtEuro(value) {
  if (value == null || isNaN(value)) return "—";
  return `${Math.round(value).toLocaleString("fr-FR")} €`;
}


// ===================================================
// TRANSPORTS : modes présents dans un bounds Leaflet
// ===================================================

export function transportsInBounds(featureCollection, bounds) {
  if (!featureCollection?.features) return [];

  return featureCollection.features.filter(f => {
    const coords = f.geometry?.coordinates;
    if (!coords) return false;

    return coords.some(([lng, lat]) =>
      bounds.contains([lat, lng])
    );
  });
}


export function extractAccessibility(features) {
  const byMode = {};

  for (const f of features) {
    const { mode, ligne, couleur } = f.properties;

    if (!mode || !ligne) continue;

    if (!byMode[mode]) byMode[mode] = new Map();

    byMode[mode].set(ligne, couleur);
  }

  return byMode;
}

