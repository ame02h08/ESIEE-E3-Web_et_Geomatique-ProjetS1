import { fmtEuro } from "../utils/utils.js";
import { computeStats } from "../models/dvf.model.js";

/* =====================================================
   PANELS
===================================================== */

export function showDeptPanel(nom, stats, transports) {
  const panel = document.getElementById("side-panel");

  panel.innerHTML = `
    <h2>${nom}</h2>

    <p>Nombre total de ventes</p>
    <div class="big-number">${stats?.ventes ?? "—"}</div>

    <p>Prix médian au m²</p>
    <div class="big-number">${fmtEuro(stats?.prixMedian)}</div>

    <hr>

    <p>Appartements</p>
    <div>${stats?.apparts ?? "—"} ventes</div>

    <p>Maisons</p>
    <div>${stats?.maisons ?? "—"} ventes</div>

    ${renderAccessibility(transports)}
  `;
}

export function showCommunePanel(nom, ventes, transports) {
  const stats = computeStats(ventes);
  const panel = document.getElementById("side-panel");

  panel.innerHTML = `
    <h2>${nom}</h2>

    <p>Nombre total de ventes</p>
    <div class="big-number">${stats.ventes}</div>

    <p>Prix médian au m²</p>
    <div class="big-number">${fmtEuro(stats.prixMedian)}</div>

    <hr>

    <p>Appartements</p>
    <div>${stats.apparts} ventes</div>
    <div>${fmtEuro(stats.prixApparts)} / m²</div>

    <p>Maisons</p>
    <div>${stats.maisons} ventes</div>
    <div>${fmtEuro(stats.prixMaisons)} / m²</div>

    ${renderAccessibility(transports)}
  `;
}

export function showSectionPanel(nomCommune, sectionCode, ventes, transports) {
  const stats = computeStats(ventes);
  const panel = document.getElementById("side-panel");

  panel.innerHTML = `
    <h2>${nomCommune}</h2>
    <h3>Section ${sectionCode}</h3>

    <p>Nombre de ventes</p>
    <div class="big-number">${stats.ventes}</div>

    <p>Prix médian au m²</p>
    <div class="big-number">${fmtEuro(stats.prixMedian)}</div>

    ${renderAccessibility(transports)}
  `;
}

/* =====================================================
   ACCESSIBILITÉ
===================================================== */

function normalizeTransports(transports) {
  if (!transports) return [];
  if (Array.isArray(transports)) return transports;
  if (transports.features) return transports.features;
  return [];
}

function buildAccessibility(transports) {
  const result = {
    METRO: new Map(),
    RER: new Map(),
    TRAMWAY: new Map(),
    TRAIN: new Map()
  };

  for (const f of transports) {
    const p = f.properties || {};
    const mode = (p.mode || "").toUpperCase();
    const ligne = p.ligne;
    const couleur = p.couleur || "#999999";

    if (!result[mode] || !ligne) continue;

    if (!result[mode].has(ligne)) {
      result[mode].set(ligne, couleur);
    }
  }

  return result;
}

function renderMode(title, map, cssClass) {
  if (!map || map.size === 0) return "";

  const items = [...map.entries()]
    .sort(([a], [b]) => a.localeCompare(b, "fr", { numeric: true }))
    .map(([ligne, couleur]) => `
      <span class="transport-badge ${cssClass}" style="--c:${couleur}">
        ${cssClass === "tram" ? "T" : ""}${ligne}
      </span>
    `)
    .join("");

  return `
    <div class="access-block">
      <h4>${title}</h4>
      <div class="access-list">${items}</div>
    </div>
  `;
}

function renderAccessibility(transports) {
  const list = normalizeTransports(transports);
  const acc = buildAccessibility(list);

  const html =
    renderMode("🚇 Métro", acc.METRO, "metro") +
    renderMode("🚆 RER", acc.RER, "rer") +
    renderMode("🚊 Tramway", acc.TRAMWAY, "tram") +
    renderMode("🚄 Train", acc.TRAIN, "rer");

  if (!html.trim()) {
    return `
      <section class="accessibility">
        <h3>Accessibilité</h3>
        <p class="muted">Aucun transport à proximité</p>
      </section>
    `;
  }

  return `
    <section class="accessibility">
      <h3>Accessibilité</h3>
      ${html}
    </section>
  `;
}
