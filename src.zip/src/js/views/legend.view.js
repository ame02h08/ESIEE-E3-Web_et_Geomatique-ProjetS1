import { heatPalette, roundDown100, roundUp100 } from "../utils/utils.js";

let legendControl = null;

export function initLegend(map) {
  legendControl = L.control({ position: "bottomleft" });

  legendControl.onAdd = () => {
    const div = L.DomUtil.create("div", "legend");
    div.innerHTML = `
      <div class="legend-title">Prix au m²</div>
      <div class="legend-bar"></div>
      <div class="legend-labels">
        <span id="legend-min">—</span>
        <span id="legend-max">—</span>
      </div>
    `;
    return div;
  };

  legendControl.addTo(map);
}

export function updateLegend(min, max) {
  if (!isFinite(min) || !isFinite(max)) return;

  const bar = document.querySelector(".legend-bar");
  if (bar) bar.style.background = `linear-gradient(to right,${heatPalette().join(",")})`;

  const minEl = document.getElementById("legend-min");
  const maxEl = document.getElementById("legend-max");

  if (minEl) minEl.textContent = `< ${roundUp100(min).toLocaleString("fr-FR")} €`;
  if (maxEl) maxEl.textContent = `> ${roundDown100(max).toLocaleString("fr-FR")} €`;
}
