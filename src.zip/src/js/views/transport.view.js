import { state } from "../app/state.js";

export function renderTransportLayer() {
  if (state.layers.transport) return state.layers.transport;

  const layer = L.geoJSON(state.data.transports, {
    style: f => ({
      color: getColor(f.properties?.mode),
      weight: 2,
      opacity: 0.7
    })
  });

  state.layers.transport = layer;
  return layer;
}

export function showTransportLayer() {
  if (!state.layers.transport) renderTransportLayer();
  state.layers.transport.addTo(state.map);
}

export function hideTransportLayer() {
  if (state.layers.transport) {
    state.map.removeLayer(state.layers.transport);
  }
}

function getColor(mode) {
  switch (mode) {
    case "METRO": return "#e10000";
    case "RER": return "#0055a4";
    case "TRAMWAY": return "#008c3c";
    case "TRAIN": return "#666666";
    default: return "#999999";
  }
}
