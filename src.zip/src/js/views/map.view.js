import { computeQuantiles, heatColorQuantile, fmtEuro } from "../utils/utils.js";
import { updateLegend } from "./legend.view.js";

export function initMap() {
  const map = L.map("map", { minZoom: 8, maxZoom: 16 }).setView([48.85, 2.35], 9);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap"
  }).addTo(map);

  return map;
}

export function clearLayer(map, layer) {
  if (layer) map.removeLayer(layer);
  return null;
}

export function renderDepartments(map, geo, statsDept, onDeptClick, getTransportLabel = null) {
  const layer = L.geoJSON(geo, {
    style: { color: "#000", weight: 2, fillOpacity: 0.12 },
    onEachFeature: (f, l) => {
      const code = f.properties.code_insee;

      const tLabel = getTransportLabel ? getTransportLabel(l.getBounds()) : null;

      l.bindTooltip(
        `<b>${f.properties.nom}</b><br>${fmtEuro(statsDept[code]?.prixMedian)} / m²` +
        (tLabel ? `<br><small>Transports : ${tLabel}</small>` : ""),
        { sticky: true }
      );

      l.on("click", () => onDeptClick(f, l));
    }
  }).addTo(map);

  map.fitBounds(layer.getBounds());
  return layer;
}

export function renderCommunes(map, geo, prixCommune, onCommuneClick, getTransportLabel = null) {
  const values = geo.features
    .map(f => prixCommune[f.properties.id])
    .filter(v => isFinite(v));

  const quantiles = computeQuantiles(values);
  if (values.length) updateLegend(Math.min(...values), Math.max(...values));

  const layer = L.geoJSON(geo, {
    style: f => ({
      fillOpacity: 0.85,
      weight: 1,
      color: "#333",
      fillColor: heatColorQuantile(prixCommune[f.properties.id], quantiles)
    }),
    onEachFeature: (f, l) => {
      const prix = prixCommune[f.properties.id];
      const tLabel = getTransportLabel ? getTransportLabel(l.getBounds()) : null;

      l.bindTooltip(
        `<b>${f.properties.nom}</b><br>${fmtEuro(prix)} / m²` +
        (tLabel ? `<br><small>Transports : ${tLabel}</small>` : ""),
        { sticky: true }
      );

      l.on("click", () => onCommuneClick(f, l));
    }
  }).addTo(map);

  return layer;
}

export function renderSections(map, features, prixSection, onSectionClick, getTransportLabel = null) {
  const values = features
    .map(f => prixSection[f.properties.id])
    .filter(v => isFinite(v));

  const quantiles = computeQuantiles(values);
  if (values.length) updateLegend(Math.min(...values), Math.max(...values));

  const layer = L.geoJSON(features, {
    style: f => ({
      fillOpacity: 0.9,
      weight: 1,
      color: "#111",
      fillColor: heatColorQuantile(prixSection[f.properties.id], quantiles)
    }),
    onEachFeature: (f, l) => {
      const tLabel = getTransportLabel ? getTransportLabel(l.getBounds()) : null;

      if (tLabel) {
        l.bindTooltip(
          `<b>Section ${f.properties.code}</b>` +
          `<br><small>Transports : ${tLabel}</small>`,
          { sticky: true }
        );
      }

      l.on("click", () => onSectionClick(f, l));
    }
  }).addTo(map);

  return layer;
}
